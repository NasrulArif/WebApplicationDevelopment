﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HOT1 : System.Web.UI.Page
{
    String name, gender, email, phone, famRide, funRide, MTBch, dateofbirth;
    int category;
    Boolean typeFamRide, typeFunRide, typeMTB;

    Double finalFee;

    protected void Page_Load(object sender, EventArgs e)
    {
        chkTypeFamRide.Checked = true;
        if (ddlCategory.SelectedValue == "Beg" || ddlCategory.SelectedValue == "Int")
        {
            chkTypeMTBChallenge.Checked = false;
            chkTypeMTBChallenge.Enabled = false;
        }
        else if (ddlCategory.SelectedValue == "Adv")
            chkTypeMTBChallenge.Enabled = true;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        name = txtName.Text;
        
        if(rdbMale.Checked == true)
            gender = "Male";
        else if (rdbFemale.Checked == true)
            gender = "Female";

        email = txtEmail.Text;
        phone = txtPhone.Text;
        dateofbirth = txtDay.Text + "/" + txtMonth.Text + "/" + txtYear.Text;

        category = ddlCategory.SelectedIndex;

        if(chkTypeFamRide.Checked == true)
        {
            typeFamRide = true;
            famRide = chkTypeFamRide.Text;
        }
        else if(chkTypeFamRide.Checked == false)
        {
            typeFamRide = false;
            famRide = String.Empty;
        }

        if(chkTypeFunRide.Checked == true)
        {
            typeFunRide = true;
            funRide = chkTypeFunRide.Text;
        }
        else if(chkTypeFunRide.Checked == false)
        {
            typeFunRide = false;
            funRide = String.Empty;
        }

        if(chkTypeMTBChallenge.Checked == true)
        {
            typeMTB = true;
            MTBch = chkTypeMTBChallenge.Text;
        }
        else if(chkTypeMTBChallenge.Checked == false)
        {
            typeMTB = false;
            MTBch = String.Empty;

        }

        finalFee = RegistrationTable(category, typeFamRide, typeFunRide, typeMTB);


        lblTQ.Text = "Thank you ";
        lblName.Text = name;
        lblDetails.Text = " for your interest! Here's your details:";
            lblDispGender.Text = "Gender :";
        lblDispEmail.Text = "Email :";
        lblDispHandphone.Text = "Handphone : ";
        lblDispDOB.Text = "Date of Birth :";
        lblDispCategory.Text = "Category :";
        lblDispType.Text = "Type :";
        lblDispFee.Text = "Fee :";

        lblOutGender.Text = gender;
        lblOutEmail.Text = email;
        lblOutHandphone.Text = phone;
        lblOutDOB.Text = dateofbirth;
        lblOutCategory.Text = Convert.ToString(ddlCategory.SelectedItem);
        lblOutType.Text = famRide + " " + funRide + " " + MTBch;
        lblOutFee.Text = Convert.ToString(finalFee);



    }


    private double RegistrationTable(int cat, Boolean a, Boolean b, Boolean c)
    {
        double totalFee = 0;

        if (cat == 0)
        {
            if (a == true)
                totalFee += 80;

            if (b == true)
                totalFee += 120;
        }
        else if (cat == 1)
        {
            if (a == true)
                totalFee += (80 * 0.06) + 80;

            if (b == true)
                totalFee += (120 * 0.06) + 120;
        }
        else if (cat == 2)
        {
            if (a == true)
                totalFee += (150 * 0.06) + 150;

            if (b == true)
                totalFee += (180 * 0.06) + 180;

            if (c == true)
                totalFee += (200 * 0.06) + 200;
        }

        return totalFee;

    }

}