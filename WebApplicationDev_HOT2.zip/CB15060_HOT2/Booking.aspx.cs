﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Booking : System.Web.UI.Page
{
    double totalfee = 0;
    double qtyChildAdult, qtySenior;

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnConfirmBook_Click(object sender, EventArgs e)
    {
        qtyChildAdult = Convert.ToDouble(txtNumChildAdult.Text);
        qtySenior = Convert.ToDouble(txtNumSenior.Text);

        

        if (rdbOneWay.Checked == true)
        {
            if (ddlDepart.SelectedIndex == 0)
            {
                if (rdbKLIA.Checked == true)
                {
                    totalfee = CalculateFee(25, qtyChildAdult, qtySenior);
                    Session["train"] = rdbKLIA.Text;
                }

                if (rdbKTM.Checked == true)
                {
                    totalfee = CalculateFee(20, qtyChildAdult, qtySenior);
                    Session["train"] = rdbKTM.Text;
                }
            }

            if (ddlDepart.SelectedIndex == 1)
            {
                if (rdbKLIA.Checked == true)
                {
                    totalfee = CalculateFee(20, qtyChildAdult, qtySenior);
                    Session["train"] = rdbKLIA.Text;
                }

                if (rdbKTM.Checked == true)
                {
                    totalfee = CalculateFee(15, qtyChildAdult, qtySenior);
                    Session["train"] = rdbKTM.Text;
                }
            }
            Session["trip"] = rdbOneWay.Text;
        }
        else if (rdbRoundTrip.Checked == true)
        {
            if (ddlDepart.SelectedIndex == 0)
            {
                if (rdbKLIA.Checked == true)
                {
                    totalfee = (CalculateFee(25, qtyChildAdult, qtySenior) + CalculateFee(20, qtyChildAdult, qtySenior)) * 0.8;
                    Session["train"] = rdbKLIA.Text;
                }

                if (rdbKTM.Checked == true)
                {
                    totalfee = (CalculateFee(20, qtyChildAdult, qtySenior) + CalculateFee(15, qtyChildAdult, qtySenior)) * 0.8;
                    Session["train"] = rdbKTM.Text;
                }
            }

            if (ddlDepart.SelectedIndex == 1)
            {
                if (rdbKLIA.Checked == true)
                {
                    totalfee = (CalculateFee(20, qtyChildAdult, qtySenior) + CalculateFee(25, qtyChildAdult, qtySenior)) * 0.8;
                    Session["train"] = rdbKLIA.Text;
                }

                if (rdbKTM.Checked == true)
                {
                    totalfee = (CalculateFee(15, qtyChildAdult, qtySenior) + CalculateFee(20, qtyChildAdult, qtySenior)) * 0.8;
                    Session["train"] = rdbKTM.Text;
                }
            }

            Session["trip"] = rdbRoundTrip.Text;
        }

        Session["name"] = txtName.Text;
        Session["depart"] = ddlDepart.SelectedValue;
        Session["arrive"] = ddlArrive.SelectedValue;
        Session["departdate"] = cdlDepart.SelectedDate.Date;
        Session["returndate"] = cdlReturn.SelectedDate.Date;
        Session["qtyChildAdult"] = qtyChildAdult;
        Session["qtySenior"] = qtySenior;
        Session["fee"] = totalfee;

        Response.Redirect("ViewBooking.aspx");
    }

    double CalculateFee(double rate, double childadult, double senior)
    {
        return((rate * childadult) + ((rate * senior)*0.5));
    }
    
}