﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewBooking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblHello.Text = Session["name"].ToString();
        lblTrip.Text = Session["trip"].ToString();
        lblDepart.Text = Session["depart"] .ToString();
        lblTo.Text = Session["arrive"].ToString();
        lblDateDepart.Text =Session["departdate"].ToString();
        lblDateReturn.Text = Session["returndate"].ToString();
        lblCompany.Text =  Session["train"].ToString();
        lblNCAdult.Text =  Session["qtyChildAdult"].ToString();
        lblSenior.Text =  Session["qtySenior"].ToString();
        lblFare.Text = "RM " + Session["fee"].ToString();
    }
}